package com.mandy.satyam.opt;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

import com.chaos.view.PinView;
import com.mandy.satyam.R;
import com.mandy.satyam.login.LoginActivity;
import com.mandy.satyam.utils.Util;


import butterknife.BindView;
import butterknife.ButterKnife;

public class OTP_verify extends AppCompatActivity {


    @BindView(R.id.loginclose)
    ImageButton loginclose;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.logintext)
    TextView logintext;
    @BindView(R.id.user_number)
    TextView userNumber;
    @BindView(R.id.editnumber)
    TextView editnumber;

    @BindView(R.id.resendotp_tv)
    TextView resendotpTv;
    @BindView(R.id.verify_otp_button)
    Button verifyOtpButton;
    Intent intent;
    String phonenumber,otp;
    PinView otpView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verify);
        ButterKnife.bind(this);
        intent = getIntent();
        otpView=(PinView)findViewById(R.id.otpView);
        if (intent!=null)
        {
            phonenumber = intent.getStringExtra("phonenumber");
            otp = intent.getStringExtra("OTP");
            userNumber.setText("+"+phonenumber);
            Util.showToastMessage(OTP_verify.this,otp,getResources().getDrawable(R.drawable.ic_error_outline_black_24dp));
        }
        lisenters();
    }

    private void lisenters() {
        loginclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        resendotpTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        editnumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OTP_verify.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });


    }
}
