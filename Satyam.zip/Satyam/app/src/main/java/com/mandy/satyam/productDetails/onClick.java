package com.mandy.satyam.productDetails;

public interface onClick {
    void GetId(String id);
}
