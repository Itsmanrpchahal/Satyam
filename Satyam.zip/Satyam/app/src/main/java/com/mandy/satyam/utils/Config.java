package com.mandy.satyam.utils;

public class Config {
    public static String GET_CATEGORY_IMAGE = "http://amrsof.tech/infedia/public/images/category_images/";
    public static String GET_PRODUCT_IMAGE = "http://amrsof.tech/infedia/public/images/product_images/";
    public static String GET_RUPPESS_SYMBOL = "\u20B9 ";
    public static String GET_MID = "ubkChc38366384537557";
}
