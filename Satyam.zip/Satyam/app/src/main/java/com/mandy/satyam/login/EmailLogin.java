package com.mandy.satyam.login;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.mandy.satyam.MainActivity;
import com.mandy.satyam.R;
import com.mandy.satyam.controller.Controller;
import com.mandy.satyam.login.model.LoginCheck;
import com.mandy.satyam.utils.Util;


import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Response;

public class EmailLogin extends AppCompatActivity implements Controller.LoginCheck {

    @BindView(R.id.loginclose)
    ImageButton loginclose;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.logintext)
    TextView logintext;
    @BindView(R.id.phone_number_et)
    EditText phoneNumberEt;
    @BindView(R.id.phn_no_layout)
    LinearLayout phnNoLayout;
    @BindView(R.id.loginwithnumber_tv)
    TextView loginwithnumber_tv;
    @BindView(R.id.continue_bt)
    Button continueBt;
    String type = "email";
    Dialog dialog;
    Controller controller;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_login);
        ButterKnife.bind(this);
        controller = new Controller(this);
        dialog = Util.showDialog(EmailLogin.this);
        lisenters();
    }

    private void lisenters() {

        loginclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        loginwithnumber_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmailLogin.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        continueBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email = phoneNumberEt.getText().toString();
                if (!email.equals("")) {

                    if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                        phoneNumberEt.setFocusable(true);
                        phoneNumberEt.setError("Enter valid email");
                    } else if (Util.isOnline(EmailLogin.this) != false) {
                        dialog.show();
                        controller.setLoginCheck(email, type);
                        Intent intent = new Intent(EmailLogin.this, MainActivity.class);
                        intent.putExtra("token", "1");
                        startActivity(intent);
                        finish();
                    } else {
                        Util.showToastMessage(EmailLogin.this, "No Internet connection", getResources().getDrawable(R.drawable.ic_nointernet));
                    }
                } else {
                    phoneNumberEt.setFocusable(true);
                    phoneNumberEt.setError("Enter email");
                }
            }
        });


    }

    @Override
    public void onSuccessLoginCheck(Response<LoginCheck> loginCheckResponse) {
        Toast.makeText(this, "" + loginCheckResponse.body().getMessage(), Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onError(String error) {
        Toast.makeText(this, "" + error, Toast.LENGTH_SHORT).show();
    }
}
